/* const S = require("sequelize")
const db = require("../db")


class Areas extends S.Model {}
Areas.init({
    name : {
        type : S.STRING
    }
}, {sequelize : db, timestamps: false, modelName : "areas"})



class Modality extends S.Model {}
Modality.init({
    name : {
        type : S.STRING
    }
}, {sequelize : db, timestamps: false, modelName : "modality"})



class Seniority extends S.Model {}
Seniority.init({
    name : {
        type : S.STRING
    }
}, {sequelize : db, timestamps: false,  modelName : "seniority"})



class States extends S.Model {}
States.init({
    name : {
        type : S.STRING
    }
}, {sequelize : db, timestamps: false, modelName : "states"})


class TypeEmployed extends S.Model {}
TypeEmployed.init({
    name : {
        type : S.STRING
    }
}, {sequelize : db, timestamps: false, modelName : "typeemloyeds"})


module.exports = {Areas, Modality, Seniority, States, TypeEmployed} */