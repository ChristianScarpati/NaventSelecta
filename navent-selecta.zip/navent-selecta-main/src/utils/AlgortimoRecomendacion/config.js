const importance = {
  areaImportance: 0.7,
  seniorityImportance: 0.6,
  ratingImportance: 0.8,
  searchQuantityImportance: 1,
}

const search = {
  Search0: 10,
  Search1: 7,
  Search2: 4,
  Search3: 1,
}

const area = {
  areamatch1: 10,
  areamatch2: 7,
  areamatch3: 4,
}
const seniority = {
  senioritymatch1: 10,
  senioritymatch2: 7,
  senioritymatch3: 4,
}

module.exports = { importance, search, area, seniority }
