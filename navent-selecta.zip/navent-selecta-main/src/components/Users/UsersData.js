const usersColumn = ['Nombre', 'Apellido', 'Mail', 'Rol', '', '']

export default usersColumn
