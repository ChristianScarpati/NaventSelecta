const jobsColums = [
    "",
    "Titulo",
    "Companía",
    "Area",
    "Seniority",
    "Tipo de empleo",
    "Modalidad",
    "Provincia",
    "Salario",
    "Estado",
    "Reclutador"
]

export default jobsColums